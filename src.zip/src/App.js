import './styles/app.scss'

import React, { Component } from 'react'

import AppBar from '@material-ui/core/AppBar'
import Grid from '@material-ui/core/Grid'
import RadioButtonCheckedIcon from '@material-ui/icons/RadioButtonChecked'
import TemplateList from './components/SideViewer/TemplateList'
import Toolbar from '@material-ui/core/Toolbar'
import Typography from '@material-ui/core/Typography'
import update from 'immutability-helper'

class App extends Component {
  constructor() {
    super()
    this.state = {
      components: [],
      showProperties: false,
      selectedIndex: null,
      fields: [],
    }
    this.onDrop = this.onDrop.bind(this)
  }

  onDrop(component) {
    const { components } = this.state
    const newComponentsList = [].concat(
      components,
      component.component.props.values
    )
    this.setState({
      components: newComponentsList,
    })
  }

  moveBox = (id, left, top) => {
    const _temp = update(this.state.components, {
      [id]: {
        $merge: { left, top },
      },
    })
    this.setState({ components: _temp })
  }

  /**
   * Remove selected class from draggable components
   */
  removeSelected = () => {
    let elems = document.querySelectorAll(".c-middlearea div[draggable='true']")

    ;[].forEach.call(elems, function(el) {
      el.classList.remove('selected')
    })
  }

  /**
   * On component select, show property viewer
   * @param {Event}
   * @param {Number}
   */
  handleFieldSection = (e, index) => {
    this.setState({
      showProperties: true,
      selectedIndex: index,
    })
  }

  /**
   * On click on cancel/save, hide property viewer
   */
  handleSelectionHide = () => {
    this.setState(
      {
        showProperties: false,
        selectedIndex: null,
      },
      () => this.removeSelected()
    )
  }

  /**
   * input and image change update state
   * @param {Event}
   * @param {Number}
   */
  handlePropsChange = (event, id) => {
    const values = [...this.state.components]
    values[id][event.target.name] = event.target.value || event.target.src

    this.setState({ components: values })
  }

  /**
   * On form sumbit update properties to state
   * @param {event}
   */
  handleSubmit = event => {
    event.preventDefault()
    const form = event.currentTarget
    const formData = new FormData(form)
    // const formProperties = JSON.stringify(Object.fromEntries(formData));
    const formProperties = Object.fromEntries(formData)
    const _id = formProperties.filedId
    const values = [...this.state.components]
    values[_id]['width'] = parseInt(formProperties['width'])
    values[_id]['height'] = parseInt(formProperties['height'])
    values[_id]['padding'] = parseInt(formProperties['padding'])
    values[_id]['margin'] = parseInt(formProperties['margin'])

    this.setState({ components: values })
    this.handleSelectionHide()
  }

  /**
   * On delete component
   * @param {event}
   * @param{Number}
   */
  handleDeleteComponents = (e, id) => {
    this.setState({
      components: this.state.components.filter((_, i) => i !== id),
    })

    this.handleSelectionHide()
  }

  render() {
    const { components, showProperties, selectedIndex } = this.state
    return (
      <div>
        <AppBar position="relative">
          <Toolbar>
            <RadioButtonCheckedIcon />
            <Typography variant="h6" color="inherit" noWrap>
              Template Designer
            </Typography>
          </Toolbar>
        </AppBar>

        <Grid container component="main">
          <Grid container>
            <Grid item xs={12} className="main-left">
              <TemplateList />
            </Grid>
          </Grid>
        </Grid>
      </div>
    )
  }
}

export default App
