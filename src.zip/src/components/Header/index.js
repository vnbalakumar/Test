import React from "react";
import { DragSource } from "react-dnd";
import TextFieldsIcon from "@material-ui/icons/TextFields";
import ImageIcon from "@material-ui/icons/Image";
import Button from "@material-ui/core/Button";
import "./index.scss";

const components = [
  <TextFieldsIcon
    values={{
      type: "input",
      top: 140,
      left: 20,
      width: 80,
      height: 30,
      padding: 0,
      margin: 0,
      title: "Enter text here",
      value: null
    }}
  />,
  <ImageIcon
    values={{
      type: "image",
      top: 20,
      left: 90,
      width: "42",
      height: "42",
      padding: 0,
      margin: 0,
      src: "/assets/img-placeholder.png",
      title: "Image Placeholder",
      value: null
    }}
  />
];
class Header extends React.Component {
  render() {
    return (
      <div className="c-form-fields">
        <ul>
          <li className="action-btns">
            <Button variant="contained" color="primary" size="small">
              Save
            </Button>
          </li>
          <li className="action-btns">
            <Button variant="contained" color="primary" size="small">
              Preview
            </Button>
          </li>
          <li className="action-btns">
            <Button variant="contained" color="primary" size="small">
              Print
            </Button>
          </li>
          {components.map((component, i) => {
            return <ListItem component={component} key={i} />;
          })}
        </ul>
      </div>
    );
  }
}

const spec = {
  beginDrag(props, monitor, component) {
    // { component: 'input' }
    const item = { ...props };
    return item;
  }
};

const collect = (connect, monitor) => {
  return {
    connectDragSource: connect.dragSource()
  };
};

const ListItem = DragSource(
  "form-elements",
  spec,
  collect
)(props => {
  const { connectDragSource, component } = props;
  return connectDragSource(<li>{component}</li>);
});

export default Header;
