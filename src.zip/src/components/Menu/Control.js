import React from 'react'

const styles = {
  border: '1px dashed gray',
  padding: '0.5rem 1rem',
  cursor: 'move',
}

const Control = props => {
  const { title, eventHandle, id, styleProps, path } = props
  const _style = { ...styleProps }
  const backgroundColor = 'white'
  let html = ''
  if (title === 'text') {
    html = (
      <label
        style={{ ..._style }}
        contentEditable={true}
        suppressContentEditableWarning={true}
      >
        Label
      </label>
    )
  } else if (title === 'image') {
    html = <img src={path} alt="Image" style={{ ..._style }} />
  }
  return (
    <div
      // dangerouslySetInnerHTML={{ __html: html }}
      style={{ ...styles, backgroundColor }}
      onDoubleClick={e => eventHandle(e, id)}
    >
      {html}
    </div>
  )
}

export default Control
