import './MenuOptions.scss'
import React from 'react'
import Button from '@material-ui/core/Button'
import Draggable from '../Draggable'
import ObjectMapperUtil from '../../common/ObjectMapperUtil'
import { CommonConstants } from '../../common/Constants'

class MenuOptions extends React.Component {
  constructor(props) {
    super(props)
  }

  state = {
    items: [
      {
        type: 'image',
        left: 0,
        top: 0,
        name: 'imageList',
        width: 80,
        height: 20,
        padding: 0,
        margin: 0,
        title: 'Enter text here',
        value: null,
      },
      {
        type: 'text',
        left: 125,
        top: 0,
        name: 'textList',
        width: 42,
        height: 42,
        padding: 0,
        margin: 0,
        src: '/assets/img-placeholder.png',
        title: 'Image Placeholder',
        value: null,
      },
    ],
  }

  handlePrint = () => {
    console.log('Print this template' + JSON.stringify(this.props.templateData))

    var src = {
      sku: '12345',
      upc: '99999912345X',
      title: 'Test Item',
      description: 'Description of test item',
      length: 5,
      width: 2,
      height: 8,
      inventory: {
        onHandQty: 12,
      },
    }

    console.log(
      `test data ${JSON.stringify(
        ObjectMapperUtil.mapData(src, CommonConstants.PrintModelType)
      )}`
    )
  }

  render() {
    return (
      <div className="c-form-fields">
        <ul>
          <li className="action-btns">
            <Button variant="contained" color="primary" size="small">
              Save
            </Button>
          </li>
          <li className="action-btns">
            <Button variant="contained" color="primary" size="small">
              Preview
            </Button>
          </li>
          <li className="action-btns">
            <Button
              variant="contained"
              color="primary"
              size="small"
              onClick={this.handlePrint}
            >
              Print
            </Button>
          </li>
        </ul>
        <div className="source">
          {this.state.items.map((item, index) => {
            return (
              <Draggable
                component={item.type}
                key={index}
                id={index}
                {...item}
              />
            )
          })}
        </div>
      </div>
    )
  }
}

export default MenuOptions
