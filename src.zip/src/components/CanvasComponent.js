import React, { Component } from 'react'
import ApiService from './../shared/ApiService'
import './CanvasComponent.css'
import { Button, CircularProgress, Snackbar } from '@material-ui/core'

// Component to preview and print template

let imageUrl = ''
class CanvasComponent extends Component {
  constructor() {
    super()
    this.apiService = new ApiService()
  }

  componentWillMount() {
    this.setState({
      loader: false,
      canvas: {
        width: '600px',
        height: '800px',
      },
      templateProperties: null, // Will be used later as dynamic
      controlsData: new Array(),
      isToastOpen: false,
    })
  }

  componentDidMount() {
    this.setState({
      loader: true,
    })

    this.apiService
      .getData('https://avanceapi.dev.target.com/avance_templates/v1/?key=test')
      // .getData('http://tcttsiss002s:8080/avance_templates/v1/?key=test')
      .then(response => {
        if (response) {
          this.setState({
            loader: false,
            controlsData: response[0].controls,
          })
          this.previewTemplate()
        } else {
          alert('No template to print')
        }
      })
  }

  previewTemplate() {
    this.setState({
      loader: true,
    })
    let data = {
      copies: 1,
      horizontal_scaling: 5,
      vertical_scaling: 5,
      preview_type: 'PNG',
      printer_name: 't9950prt0101',
      template: {
        name: 'DefectiveLabel',
        user_id: 'Z063555',
        height: 77.8,
        width: 127.6,
        orientation: 'LANDSCAPE',
        controls: this.state.controlsData,
      },
    }

    this.apiService
      .postImageData(
        'https://avanceapi.dev.target.com/avance_templates/v1/preview_templates?key=test',
        // 'http://tcttsiss002s:8080/avance_templates/v1/preview_templates?key=test',
        data
      )
      .then(response => {
        this.setState({
          loader: false,
        })
        const context = this.canvas.getContext('2d')
        const image = new Image()
        image.src = response
        image.onload = () => {
          context.drawImage(image, 0, 0, this.canvas.width, this.canvas.height)
        }
      })
  }

  printTemplate = () => {
    this.setState({
      loader: true,
    })

    let data = {
      copies: 1,
      is_summary: true,
      printer_name: 't9778PRT0101',
      summary: true,
      template: {
        name: 'DefectiveLabel',
        user_id: 'Z063555',
        height: 77.8,
        width: 127.6,
        orientation: 'LANDSCAPE',
        controls: this.state.controlsData,
      },
    }

    this.apiService
      .postData(
        // 'https://avanceapi.dev.target.com/avance_templates/v1/print_templates?key=test',
        'http://tcttsiss002s:8080/avance_templates/v1/print_templates?key=test',
        data
      )
      .then(response => {
        if (response) {
          this.setState({
            loader: false,
            isToastOpen: true,
          })
        }
        this.previewTemplate()
      })
  }

  createTemplate = () => {
    this.setState({
      loader: true,
    })

    let data = {
      name: 'ClearanceLabel',
      user_id: 'Z001HRF',
      height: 77.8,
      width: 127.6,
      id: 1,
      orientation: 'LANDSCAPE',
      controls: this.state.controlsData, // Todo: This has to take controls from user created templates in future.
    }

    this.apiService
      .postData(
        'https://avanceapi.dev.target.com/avance_templates/v1/?key=test',
        // 'http://tcttsiss002s:8080/avance_templates/v1/?key=test',
        data
      )
      .then(response => {
        if (response) {
          this.setState({
            loader: false,
            isToastOpen: true,
          })
        }
      })
  }

  deleteTemplate = () => {
    this.setState({
      loader: true,
    })

    this.apiService
      .deleteData(
        'https://avanceapi.dev.target.com/avance_templates/v1/1?key=test'
      )
      // .getData('http://tcttsiss002s:8080/avance_templates/v1/?key=test')
      .then(response => {
        this.setState({
          loader: false,
        })
      })
  }

  handleClose = () => this.setState({ isToastOpen: false })

  render() {
    if (this.state.loader) return <CircularProgress />

    return (
      <div>
        <div>
          <canvas
            ref={canvas => (this.canvas = canvas)}
            className="canvas-ctrl"
          >
            <img ref="image" src={imageUrl} className="hidden" />
          </canvas>
        </div>

        <Button
          variant="contained"
          color="primary"
          onClick={this.printTemplate}
          className="btn-ctrl"
        >
          Print
        </Button>

        <Button
          variant="contained"
          color="primary"
          onClick={this.createTemplate}
          className="btn-ctrl"
        >
          Create template
        </Button>

        <Button
          variant="contained"
          color="primary"
          onClick={this.deleteTemplate}
          className="btn-ctrl"
        >
          Delete template
        </Button>

        <Snackbar
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'center',
          }}
          open={this.state.isToastOpen}
          onClose={this.handleClose}
          ContentProps={{
            'aria-describedby': 'message-id',
          }}
          message={
            <span id="message-id">Successfully performed the operation</span>
          }
        />
      </div>
    )
  }
}
export default CanvasComponent
