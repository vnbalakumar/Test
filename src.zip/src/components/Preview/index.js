import "./index.scss";

import Container from "@material-ui/core/Container";
import React from "react";

function getStyle(style) {
  const { top, left, width, height, padding, margin } = style;
  return {
    position: "absolute",
    top: top,
    left: left,
    width: width,
    height: height,
    padding: padding,
    margin: margin
  };
}

const Preview = () => {
  const localData = localStorage.getItem("preview");
  const data = localData ? JSON.parse(localStorage.getItem("preview")) : [];
  console.log(data);
  return (
    <Container maxWidth="sm">
      <div className="c-preview-title">Preview</div>
      <div className="c-preview">
        {data &&
          data.map(function(d, i) {
            if (d.type === "image") {
              return (
                <img key={i} style={getStyle(d)} src={d.src} alt="image" />
              );
            }
            return (
              <label key={i} style={getStyle(d)}>
                {d.value || d.title}
              </label>
            );
          })}
      </div>
    </Container>
  );
};

export default Preview;