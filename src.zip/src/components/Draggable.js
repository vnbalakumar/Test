import Control from './Menu/Control'
import { DragSource } from 'react-dnd'
import React from 'react'
import { getEmptyImage } from 'react-dnd-html5-backend'

function getStyles(props) {
  const { left, top, isDragging } = props
  const transform = `translate3d(${left}px, ${top}px, 0)`

  return {
    position: 'absolute',
    transform,
    WebkitTransform: transform,
    opacity: isDragging ? 0 : 1,
    height: isDragging ? 0 : '',
  }
}

function getComponentStyle(props) {
  const { width, height, padding, margin } = props
  return {
    width: width,
    height: height,
    padding: padding,
    margin: margin,
  }
}

class Draggable extends React.Component {
  componentDidMount() {
    const { connectDragPreview } = this.props
    if (connectDragPreview) {
      connectDragPreview(getEmptyImage(), {
        captureDraggingState: true,
      })
    }
  }

  /**
   * Remove selected class form draggable components
   */
  removeSelected = () => {
    let elems = document.querySelectorAll(
      ".drawable-area div[draggable='true'] > div"
    )

    ;[].forEach.call(elems, function(el) {
      el.classList.remove('selected')
    })
  }

  /**
   * Add selected class to selected item
   * @param {Event} e
   * @param {Number} index
   */
  highlightSelected = (e, index) => {
    if (e) {
      const $target = e.currentTarget
      this.removeSelected()
      $target.classList.add('selected')
      this.props.event(e, index)
    }
  }

  render() {
    const { isDragging, connectDragSource, component } = this.props
    const opacity = isDragging ? 0 : 1
    return connectDragSource(
      <div style={getStyles(this.props)}>
        <Control
          title={component}
          id={this.props.id}
          eventHandle={this.highlightSelected}
          styleProps={getComponentStyle(this.props)}
          path={this.props.src}
        />
      </div>
    )
  }
}

export default DragSource(
  'item',
  {
    beginDrag(props) {
      const { id, name, left, top, type } = props
      return { id, name, left, top, type }
    },
  },
  (connect, monitor) => ({
    connectDragSource: connect.dragSource(),
    connectDragPreview: connect.dragPreview(),
    isDragging: monitor.isDragging(),
  })
)(Draggable)
