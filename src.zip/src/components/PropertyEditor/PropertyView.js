import './PropertyView.scss'

import Button from '@material-ui/core/Button'
import CancelIcon from '@material-ui/icons/Cancel'
import DeleteForeverIcon from '@material-ui/icons/DeleteForever'
import Grid from '@material-ui/core/Grid'
import React from 'react'
import SaveIcon from '@material-ui/icons/Save'
import TextField from '@material-ui/core/TextField'

/**
 * Dummy image list
 * TODO :: replace with services
 */
const imageData = [
  {
    img: '/assets/logo-1.png',
    title: 'Image',
    author: 'author',
    id: 1,
  },
  {
    img: '/assets/img-2.png',
    title: 'Image',
    id: 2,
  },
  {
    img: '/assets/img-3.png',
    title: 'Image',
    id: 3,
  },
  {
    img: '/assets/img-4.png',
    title: 'Image',
    id: 4,
  },
]

const PropertyView = props => {
  let { width, height, padding, margin, type } = props.controls[
    props.selectedIndex
  ]
  return (
    <div className="c-props-views">
      <h4>Set control properties here</h4>
      <Grid container>
        <Grid item>
          <form onSubmit={props.handleSubmit} noValidate autoComplete="off">
            <input type="hidden" name="filedId" value={props.selectedIndex} />
            <TextField
              id="fwidth"
              label="With"
              type="number"
              name="width"
              variant="outlined"
              // onChange={e => props.handleChange(e, props.selectedIndex)}
              defaultValue={width || 0}
              InputLabelProps={{
                shrink: true,
              }}
            />
            <TextField
              id="fheight"
              label="Height"
              type="number"
              name="height"
              variant="outlined"
              // onChange={e => props.handleChange(e, props.selectedIndex)}
              defaultValue={height || 0}
              InputLabelProps={{
                shrink: true,
              }}
            />

            <TextField
              id="fpadding"
              label="Padding"
              type="number"
              name="padding"
              variant="outlined"
              // onChange={e => props.handleChange(e, props.selectedIndex)}
              defaultValue={padding || 0}
              InputLabelProps={{
                shrink: true,
              }}
            />

            <TextField
              id="fmargin"
              label="Margin"
              type="number"
              name="margin"
              variant="outlined"
              // onChange={e => props.handleChange(e, props.selectedIndex)}
              defaultValue={margin || 0}
              InputLabelProps={{
                shrink: true,
              }}
            />

            {type === 'image' && (
              <>
                <h5>Image gallery</h5>
                <ul className="image-list">
                  {imageData.map(tile => (
                    <li key={tile.id} cols={tile.cols || 1}>
                      <img
                        src={tile.img}
                        alt={tile.title}
                        name="src"
                        value={tile.img}
                        onClick={e =>
                          props.handleChange(e, props.selectedIndex)
                        }
                      />
                    </li>
                  ))}
                </ul>
              </>
            )}
            <Grid item>
              <Button variant="outlined" onClick={props.hide} title="Cancel">
                <CancelIcon />
              </Button>
              <Button
                variant="outlined"
                color="secondary"
                title="Delete"
                style={{ marginLeft: 5 }}
                onClick={e => props.delete(e, props.selectedIndex)}
              >
                <DeleteForeverIcon />
              </Button>
              <Button
                variant="contained"
                color="primary"
                type="submit"
                title="save"
                style={{ marginLeft: 5 }}
              >
                <SaveIcon />
              </Button>
            </Grid>
          </form>
        </Grid>
      </Grid>
    </div>
  )
}

export default PropertyView
