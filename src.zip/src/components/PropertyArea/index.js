import React from "react";
import Grid from "@material-ui/core/Grid";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import CancelIcon from "@material-ui/icons/Cancel";
import DeleteForeverIcon from "@material-ui/icons/DeleteForever";
import SaveIcon from "@material-ui/icons/Save";
import "./index.scss";

const tileData = [
  {
    img: "/assets/logo-1.png",
    title: "Image",
    author: "author",
    cols: 2
  },
  {
    img: "/assets/img-2.png",
    title: "Image",
    author: "author",
    cols: 2
  }
];

const RightSide = props => {
  let { width, height, padding, margin, type } = props.components[
    props.selectedIndex
  ];
  return (
    <div className="c-props-views">
      <h4>Properties Viewer</h4>
      <Grid container>
        <Grid item>
          <form onSubmit={props.handleSubmit} noValidate autoComplete="off">
            <input type="hidden" name="filedId" value={props.nodeIndex} />
            <TextField
              id="fwidth"
              label="With"
              type="number"
              name="width"
              variant="outlined"
              onChange={e => props.handleChange(e, props.selectedIndex)}
              value={width || ""}
              InputLabelProps={{
                shrink: true
              }}
            />
            <TextField
              id="fheight"
              label="Height"
              type="number"
              name="height"
              variant="outlined"
              onChange={e => props.handleChange(e, props.selectedIndex)}
              value={height || ""}
              InputLabelProps={{
                shrink: true
              }}
            />

            <TextField
              id="fpadding"
              label="Padding"
              type="number"
              name="padding"
              variant="outlined"
              onChange={e => props.handleChange(e, props.selectedIndex)}
              value={padding || ""}
              InputLabelProps={{
                shrink: true
              }}
            />

            <TextField
              id="fmargin"
              label="Margin"
              type="number"
              name="margin"
              variant="outlined"
              onChange={e => props.handleChange(e, props.selectedIndex)}
              value={margin || ""}
              InputLabelProps={{
                shrink: true
              }}
            />

            {type === "image" && (
              <ul className="image-list">
                {tileData.map(tile => (
                  <li key={tile.img} cols={tile.cols || 1}>
                    <img
                      src={tile.img}
                      alt={tile.title}
                      name="src"
                      value={tile.img}
                      onClick={e => props.handleChange(e, props.selectedIndex)}
                    />
                  </li>
                ))}
              </ul>
            )}
            <Grid item>
              <Button variant="outlined" onClick={props.hide} title="Cancel">
                <CancelIcon />
              </Button>
              <Button
                variant="outlined"
                color="secondary"
                title="Delete"
                style={{ marginLeft: 5 }}
                onClick={e => props.delete(e, props.selectedIndex)}
              >
                <DeleteForeverIcon />
              </Button>
              <Button
                variant="contained"
                color="primary"
                type="submit"
                title="save"
                style={{ marginLeft: 5 }}
              >
                <SaveIcon />
              </Button>
            </Grid>
          </form>
        </Grid>
      </Grid>
    </div>
  );
};

export default RightSide;
