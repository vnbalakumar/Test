import React from 'react'
import TreeItem from '@material-ui/lab/TreeItem'
import { fade, withStyles } from '@material-ui/core/styles'
import Collapse from '@material-ui/core/Collapse'

function TransitionComponent(props) {
  const style = {
    from: { opacity: 0, transform: 'translate3d(20px,0,0)' },
    to: {
      opacity: props.in ? 1 : 0,
      transform: `translate3d(${props.in ? 0 : 20}px,0,0)`,
    },
  }

  return (
    <div style={style}>
      <Collapse {...props} />
    </div>
  )
}

class StyledTreeItem extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    return (
      <TreeItem {...this.props} TransitionComponent={TransitionComponent} />
    )
  }
}

export default withStyles(theme => ({
  iconContainer: {
    '& .close': {
      opacity: 0.3,
    },
  },
  group: {
    marginLeft: 12,
    paddingLeft: 12,
    borderLeft: `1px dashed ${fade(theme.palette.text.primary, 0.4)}`,
  },
}))(StyledTreeItem)
