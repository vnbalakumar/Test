import Draggable from '../Draggable'
import { DropTarget } from 'react-dnd'
import PropertyView from '../PropertyEditor/PropertyView'
import React from 'react'
import MenuOptions from '../Menu/MenuOptions'

const styles = {
  width: '90%',
  height: 300,
  border: '2px solid #ddd',
  position: 'relative',
  marginLeft: 50,
}

class DrawableArea extends React.Component {
  state = {
    controls: [],
    showProperties: false,
    selectedIndex: null,
  }

  componentWillReceiveProps() {
    this.setState({
      controls: this.props.controls,
    })
  }
  /**
   * Remove selected class from draggable components
   */
  removeSelected = () => {
    let elems = document.querySelectorAll(
      ".drawable-area div[draggable='true'] > div"
    )

    ;[].forEach.call(elems, function(el) {
      el.classList.remove('selected')
    })
  }

  /**
   * On component select, show property viewer
   * @param {Event}
   * @param {Number}
   */
  handleFieldSection = (e, index) => {
    this.setState({
      showProperties: true,
      selectedIndex: index,
    })
  }

  /**
   * On click on cancel/save, hide property viewer
   */
  handleSelectionHide = () => {
    this.setState(
      {
        showProperties: false,
        selectedIndex: null,
      },
      () => this.removeSelected()
    )
  }

  /**
   * input and image change update state
   * @param {Event}
   * @param {Number}
   */
  handlePropsChange = (event, id) => {
    const values = [...this.state.controls]
    values[id][event.target.name] = event.target.value || event.target.src

    this.setState({ controls: values })
  }

  /**
   * On form sumbit update properties to state
   * @param {event}
   */
  handleSubmit = event => {
    event.preventDefault()
    const form = event.currentTarget
    const formData = new FormData(form)
    const formProperties = Object.fromEntries(formData)
    const _id = formProperties.filedId
    const values = [...this.state.controls]
    values[_id]['width'] = parseInt(formProperties['width'])
    values[_id]['height'] = parseInt(formProperties['height'])
    values[_id]['padding'] = parseInt(formProperties['padding'])
    values[_id]['margin'] = parseInt(formProperties['margin'])

    this.setState({ controls: values })
    this.handleSelectionHide()
  }

  /**
   * On delete component
   * @param {event}
   * @param{Number}
   */
  handleDeleteComponents = (e, id) => {
    this.setState({
      items: this.state.controls.filter((_, i) => i !== id),
    })

    this.handleSelectionHide()
  }

  render() {
    const { connectDropTarget } = this.props
    const { controls, showProperties, selectedIndex } = this.state

    return (
      <div>
        {/* Child component Control Source which will take care of saving/previewing and printing templates */}
        <MenuOptions templateData={this.state.controls} />

        <div className="drawable-area">
          {connectDropTarget(
            <div style={styles}>
              {controls.map((control, index) => this.renderBox(control, index))}
            </div>
          )}
          {showProperties && (
            <div className="main-right">
              <PropertyView
                hide={this.handleSelectionHide}
                delete={this.handleDeleteComponents}
                handleChange={this.handlePropsChange}
                handleSubmit={this.handleSubmit}
                selectedIndex={selectedIndex}
                {...this.state}
              />
            </div>
          )}
        </div>
      </div>
    )
  }

  moveBox(id, left, top) {
    var currentState = this.state
    currentState.controls[id].left = left
    currentState.controls[id].top = top
    this.setState(currentState)
  }

  dropFromOutside(control) {
    var currentState = this.state

    switch (control.type.toUpperCase()) {
      case 'TEXT':
        currentState.controls.push({
          type: control.type,
          left: 0,
          top: 0,
          height: 30,
          width: 70,
          name: `TEXT_CONTROL_${Math.random().toFixed()}`, // generates unique identifier for text control
          alignment: 'CENTER',
          text: 'Placeholder text',
          value: 'Placeholder text',
        })
        break

      case 'IMAGE':
        currentState.controls.push({
          type: control.type,
          left: 0,
          top: 0,
          height: 30,
          width: 70,
          name: `IMAGE_CONTROL_${Math.random().toFixed()}`, // generates unique identifier for image control
          alignment: 'CENTER',
          src: '/assets/img-placeholder.png',
        })

      default:
        break
    }

    this.setState(currentState)
  }
  renderBox(control, key) {
    return (
      <Draggable
        component={control.type}
        key={key}
        id={key}
        {...control}
        event={this.handleFieldSection}
      />
    )
  }
}

export default DropTarget(
  'item',
  {
    drop(props, monitor, component) {
      if (!component) {
        return
      }
      const delta = monitor.getDifferenceFromInitialOffset()
      const item = monitor.getItem()

      let left =
        item.left !== undefined ? Math.round(item.left + delta.x) : null
      let top = item.top !== undefined ? Math.round(item.top + delta.y) : null

      if (item.name.includes('List')) {
        component.dropFromOutside(item)
      } else {
        component.moveBox(item.id, left, top)
      }
    },
  },
  connect => ({
    connectDropTarget: connect.dropTarget(),
  })
)(DrawableArea)
