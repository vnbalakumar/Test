import React from 'react'
import { DragSource } from 'react-dnd'
import { getEmptyImage } from 'react-dnd-html5-backend'
import Control from './Control'

function getStyles(props) {
  const { left, top, isDragging } = props
  const transform = `translate3d(${left}px, ${top}px, 0)`

  return {
    position: 'absolute',
    transform,
    WebkitTransform: transform,
    opacity: isDragging ? 0 : 1,
    height: isDragging ? 0 : '',
  }
}

class Draggable extends React.Component {
  componentDidMount() {
    const { connectDragPreview } = this.props
    if (connectDragPreview) {
      connectDragPreview(getEmptyImage(), {
        captureDraggingState: true,
      })
    }
  }

  render() {
    const { isDragging, connectDragSource, component } = this.props
    const opacity = isDragging ? 0 : 1
    return connectDragSource(
      <div style={getStyles(this.props)}>
        <Control title={component} />
      </div>
    )
  }
}

export default DragSource(
  'item',
  {
    beginDrag(props) {
      const { id, description, left, top, type } = props
      return { id, description, left, top, type }
    },
  },
  (connect, monitor) => ({
    connectDragSource: connect.dragSource(),
    connectDragPreview: connect.dragPreview(),
    isDragging: monitor.isDragging(),
  })
)(Draggable)
