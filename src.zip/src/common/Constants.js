export const CommonConstants = {
  SupportedElementsForDesigner: 'label,img',
  PrintModelType: 'PRINT_REQUEST',
}
