import { CommonConstants } from './Constants'

class PrintManagementMappers {
  //  This class holds all the mappers rules across Print management application.
  static getMappers = modelType => {
    var map = new Object()
    switch (modelType.toUpperCase()) {
      case CommonConstants.PrintModelType:
        map = {
          sku: 'Envelope.Request.Item.SKU',
          upc: 'Envelope.Request.Item.UPC',
          title: 'Envelope.Request.Item.ShortTitle',
          description: 'Envelope.Request.Item.ShortDescription',
          length: 'Envelope.Request.Item.Dimensions.Length',
          width: 'Envelope.Request.Item.Dimensions.Width',
          height: 'Envelope.Request.Item.Dimensions.Height',
          'inventory.onHandQty': 'Envelope.Request.Item.Inventory',
        }
        break

      default:
        break
    }
    return map
  }
}
export default PrintManagementMappers
