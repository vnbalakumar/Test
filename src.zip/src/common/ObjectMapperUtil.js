// import ObjectMapper from 'object-mapper'
// import PrintManagementMappers from './PrintManagementMappers'

// class ObjectMapperUtil {
//   static mapData(sourceObj, modelType) {
//     var outputObject = ObjectMapper.merge(
//       sourceObj,
//       PrintManagementMappers.getMappers(modelType)
//     )
//     return outputObject
//   }
// }

// export default ObjectMapperUtil
