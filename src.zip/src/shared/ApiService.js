export default class ApiService {
  async getData(url) {
    return fetch(url)
      .then(response => {
        if (!response.ok) {
          this.handleResponseError(response)
        }
        return response.json()
      })
      .then(jsonResponse => {
        console.log(`data fetched as ${jsonResponse}`)
        return jsonResponse
      })
      .catch(error => {
        this.handleError(error)
      })
  }

  async postData(url, requestBody) {
    return fetch(url, {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    })
      .then(response => {
        if (!response.ok) {
          this.handleResponseError(response)
        }
        return response
      })
      .catch(error => {
        this.handleError(error)
      })
  }

  async postImageData(url, requestBody) {
    return fetch(url, {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    })
      .then(response =>
        response.arrayBuffer().then(buffer => {
          var base64Flag = 'data:image/png;base64,'
          var imageStr = this.arrayBufferToBase64(buffer)
          return base64Flag + imageStr
        })
      )
      .catch(error => {
        this.handleError(error)
      })
  }

  async deleteData(url) {
    return fetch(url, {
      method: 'DELETE',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
      },
    })
      .then(response => {
        if (!response.ok) {
          this.handleResponseError(response)
        }
        return response
      })
      .catch(error => {
        this.handleError(error)
      })
  }

  arrayBufferToBase64(buffer) {
    var binary = ''
    var bytes = [].slice.call(new Uint8Array(buffer))

    bytes.forEach(b => (binary += String.fromCharCode(b)))

    return window.btoa(binary)
  }

  handleResponseError(response) {
    throw new Error('HTTP error, status = ' + response.status)
  }

  handleError(error) {
    alert('Failed to perform requested operation')
  }
}
