import React from 'react'
import { DropTarget } from 'react-dnd'
import Draggable from './Draggable'

const styles = {
	width: 800,
	height: 300,
	border: '1px solid black',
	position: 'relative',
}

class DrawableArea extends React.Component {
	state = {
		items: [
			{ type: 'image', top: 0, left: 150, description: 'imageCanvas' },
			{ type: 'text', top: 180, left: 150, description: 'textCanvas' },
		],
	}

	render() {
		const { connectDropTarget } = this.props
		const { items } = this.state

		return connectDropTarget(
			<div style={styles}>
				{items.map((item, index) => this.renderBox(item, index))}
			</div>,
		)
	}

	moveBox(id, left, top) {
		var currentState = this.state;
		currentState.items[id].left = left
		currentState.items[id].top = top
		this.setState(currentState);
	}

	dropFromOutside(item) {
		var currentState = this.state;
		currentState.items.push({ type: item.type, top: 0, left: 0, description: item.type + 'Canvas' })
		this.setState(currentState);
	}
	renderBox(item, key) {
		return <Draggable component={item.type} key={key} id={key} {...item} />
	}
}

export default DropTarget(
	'item',
	{
		drop(
			props,
			monitor,
			component,
		) {
			if (!component) {
				return
			}
			const delta = monitor.getDifferenceFromInitialOffset()
			const item = monitor.getItem()

			let left = item.left !== undefined ? Math.round(item.left + delta.x) : null
			let top = item.top !== undefined ? Math.round(item.top + delta.y) : null

			if (item.description.includes('List')) {
				component.dropFromOutside(item)
			}
			else {
				component.moveBox(item.id, left, top)
			}
		},
	},
	(connect) => ({
		connectDropTarget: connect.dropTarget(),
	}),
)(DrawableArea)
