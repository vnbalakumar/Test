export const CommonConstants = {
  SupportedElementsForDesigner: 'label,img',
}
