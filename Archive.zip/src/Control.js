import React from 'react'

const styles = {
  border: '1px dashed gray',
  padding: '0.5rem 1rem',
  cursor: 'move',
}

const Control = ({ title, yellow }) => {
  const backgroundColor = yellow ? 'yellow' : 'white'
  let html = ''
  if (title === 'text') {
    html = `<label contenteditable>Enter label</label>`
  } else if (title === 'image') {
    html = '<img src="" alt="test image">'
  }
  return (
    <div
      dangerouslySetInnerHTML={{ __html: html }}
      style={{ ...styles, backgroundColor }}
    />
  )
}

export default Control
