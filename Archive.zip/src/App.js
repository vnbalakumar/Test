import React, { Component } from 'react'
import ControlSource from './ControlSource'
import DrawableArea from './DrawableArea'
import { DragDropContext } from 'react-dnd'
import Backend from 'react-dnd-html5-backend'
import _ from 'lodash'
import './App.css'

import TemplateList from "./components/TemplateList";
import Header from "./components/Header";
// import TemplateArea from "./components/TemplateArea";
//import Container from "./components/TemplateArea/Container";
import PropertyArea from "./components/PropertyArea";
import { DndProvider } from "react-dnd";
import "./styles/app.scss";

import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import Grid from "@material-ui/core/Grid";
import update from "immutability-helper";

class App extends Component {
  constructor() {
    super()
    this.state = {
      components: [],
      showProperties: false,
      selectedIndex: null,
      fields: []
    }
    this.onDrop = this.onDrop.bind(this)
  }

  onDrop(component) {
    const { components } = this.state
    console.log(component)
    const newComponentsList = _.concat([], components, component)
    this.setState({
      components: newComponentsList,
    })
  }

  moveBox = (id, left, top) => {
    const _temp = update(this.state.components, {
      [id]: {
        $merge: { left, top }
      }
    });
    this.setState({ components: _temp });
  };

  handleFieldChange = (e, id) => {
    const value = e.currentTarget.value;
    const _temp = update(this.state.components, {
      [id]: {
        $merge: { value }
      }
    });
    this.setState({ components: _temp });
  };

  removeSelected = () => {
    let elems = document.querySelectorAll(
      ".c-middlearea div[draggable='true']"
    );

    [].forEach.call(elems, function(el) {
      el.classList.remove("selected");
    });
  };

  handleFieldSection = (e, index) => {
    this.setState({
      showProperties: true,
      selectedIndex: index
    });
  };

  handleSelectionHide = () => {
    this.setState(
      {
        showProperties: false,
        selectedIndex: null
      },
      () => this.removeSelected()
    );
  };

  handlePropsChange = (event, id) => {
    const values = [...this.state.components];
    values[id][event.target.name] = event.target.value || event.target.src;

    this.setState({ components: values });
  };

  handleSubmit = event => {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const formProperties = JSON.stringify(Object.fromEntries(formData));
    console.log(formProperties);
    this.handleSelectionHide();
  };

  handleDeleteComponents = (e, id) => {
    this.setState({
      components: this.state.components.filter((_, i) => i !== id)
    });

    this.handleSelectionHide();
  };

  render() {
    const { components, showProperties } = this.state;
    console.log('state components ', components)
    return (
      <div className="App">
        {/* <ControlSource />
        <DrawableArea onDrop={this.onDrop} components={components} /> */}
                <AppBar position="relative">
          <Toolbar>
            <RadioButtonCheckedIcon />
            <Typography variant="h6" color="inherit" noWrap>
              Template Designer
            </Typography>
          </Toolbar>
        </AppBar>
        <Grid container component="main">
          <Grid item xs={12}>
            <Grid container>
              <Grid item xs={2} className="main-left">
                <TemplateList />
              </Grid>
              <Grid item xs={8}>
                <DndProvider backend={Backend}>
                  <Grid item className="c-header">
                    <Header />
                  </Grid>
                  <Grid container>
                    {/* <Grid item xs className="main-body">
                      <Container
                        onDrop={this.onDrop}
                        onMove={this.moveBox}
                        components={components}
                        event={this.handleFieldSection}
                        handleFieldChange={this.handleFieldChange}
                      />
                    </Grid> */}
                    <ControlSource />
                    <DrawableArea onDrop={this.onDrop} components={components} />
                  </Grid>
                </DndProvider>
              </Grid>
              {showProperties && (
                <Grid item xs={2} className="main-right">
                  <PropertyArea
                    hide={this.handleSelectionHide}
                    delete={this.handleDeleteComponents}
                    handleChange={this.handlePropsChange}
                    handleSubmit={this.handleSubmit}
                    {...this.state}
                  />
                </Grid>
              )}
            </Grid>
          </Grid>
        </Grid>
      </div>
    )
  }
}

export default App;
//export default DragDropContext(Backend)(App)
