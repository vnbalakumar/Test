import React from 'react';
import { DragSource } from 'react-dnd';
import './controlSource.css';
import Draggable from './Draggable';

class ControlSource extends React.Component {
    state = {
      items: [
        {type: 'image', top: 0, left: 0, description: 'imageList' },
        {type: 'text', top: 40, left: 0, description: 'textList' },
      ],
    }
    render() {
        return (
            <div className="source">
                <ul>
                    {
                        this.state.items.map((item,index) => {
                          return <Draggable component= {item.type} key={index} id={index} {...item} />
                        })
                    }
                </ul>
            </div>
        )
    }
}

const spec = {
    beginDrag(props, monitor, component) {
        const item = { ...props };
        return item;
    }
};

const collect = (connect, monitor) => {
    return {
        connectDragSource: connect.dragSource()
    };
}

export default ControlSource
